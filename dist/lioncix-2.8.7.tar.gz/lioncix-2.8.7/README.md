## 📸 LionCix HackForge Launcher

| LionCix | HackForge | Launcher |
|-------|--------|--------|
| <img src="https://github.com/Royhtml/LionCix-Images/raw/main/14.png" width="200" height="400"> | <img src="https://github.com/Royhtml/LionCix-Images/raw/main/2.png" width="200" height="400"> | <img src="https://github.com/Royhtml/LionCix-Images/raw/main/3.png" width="200" height="400"> |
| <img src="https://github.com/Royhtml/LionCix-Images/raw/main/4.png" width="200" height="400"> | <img src="https://github.com/Royhtml/LionCix-Images/raw/main/5.png" width="200" height="400"> | <img src="https://github.com/Royhtml/LionCix-Images/raw/main/6.png" width="200" height="400"> |
| <img src="https://github.com/Royhtml/LionCix-Images/raw/main/7.png" width="200" height="400"> | <img src="https://github.com/Royhtml/LionCix-Images/raw/main/9.png" width="200" height="400"> | <img src="https://github.com/Royhtml/LionCix-Images/raw/main/10.png" width="200" height="400"> |
| <img src="https://github.com/Royhtml/LionCix-Images/raw/main/11.png" width="200" height="400"> | <img src="https://github.com/Royhtml/LionCix-Images/raw/main/12.png" width="200" height="400"> | <img src="https://github.com/Royhtml/LionCix-Images/raw/main/13.png" width="200" height="400"> |
-----

## 🦁 LIONCIX HACKFORGE

**PROFESSIONAL Hacker V2.8.7**
**Created by Dwi Bakti N Dev**

## Setup Install Termux
``Pkg Update``

``pkg install python``

``pkg install git``

``git clone https://github.com/Royhtml/lioncix``

``cd lioncix``

``python main.py``

## Setup Install Windows & Macos & Linux

``pip install lioncix``

``lioncix``

Info : Pastikan Anda Install Terlebih Dahulu Python Patch

### 📝 Deskripsi Proyek

**LIONCIX HACKFORGE** adalah paket alat multifungsi yang dirancang untuk kebutuhan keamanan siber, pengembangan web, dan pengumpulan informasi. Alat ini menggabungkan berbagai utilitas mulai dari pemindaian keamanan situs web, manajemen *tools* *hacking*, alat OSINT, hingga fungsi *token generator* dan pengembangan PHP.

Proyek ini bertujuan untuk menyediakan *interface* berbasis terminal yang ringkas dan mudah digunakan, yang kompatibel dengan platform **Windows** dan lingkungan **Termux**.

### 🌟 Fitur Utama

Berdasarkan struktur menu, LIONCIX HACKFORGE menyediakan fitur-fitur berikut:

  * **Pemindaian Keamanan Website:** Melakukan *scan* lengkap, mendeteksi kerentanan **SQL Injection**, **XSS**, *port scanning*, *DNS/WHOIS lookup*, *SSL/TLS check*, *subdomain scanning*, dan banyak lagi.

  * **Manajemen Alat:** Memungkinkan instalasi koleksi *tools* *hacking* dan menjalankan *tools* yang sudah terinstal.

  * **Pengembangan Web:** Menyediakan manajer proyek PHP (*Create/Run/Delete*).

  * **Alat Lanjutan:** Fitur seperti **Backend & PHP Analysis**, **cPanel Project Dumper**, dan **DDoS Attack Tools**.

  * **OSINT & Media Sosial:** Alat untuk OSINT (Open Source Intelligence) termasuk **Phone Number Lookup** dan **Social Media Tools** (*Followers/Views*).

  * **Token Generator:** Menu khusus untuk menghasilkan, memverifikasi, mengimpor, dan mengekspor berbagai jenis *token* (*Demo, Quick, Custom, Bulk*).

  * **Utilitas Sistem:** Menjalankan *Script Python*, *Server Web*, *Install Packages*, *Update Pip*, dan melihat *Informasi Sistem*.

  * **Setup LENGKAP:** Termasuk instalasi **Apache** dan **MariaDB** serta pengelolaan layanannya (Start/Stop/Restart) dan akses ke **Web Interface** dan **PhpMyAdmin**.

  * **Download & Sumber Daya:** Menyediakan akses ke sumber daya seperti koleksi virus (**Download Virus Collection**) dari GitHub.

### 💻 Instalasi & Persyaratan Sistem

Proyek ini dirancang untuk dijalankan pada:

1.  **Windows**
2.  **Termux** (Android/Linux-like Environment)

#### Persyaratan Minimal:

  * Akses ke Terminal/Command Prompt.
  * Pemasangan Python (untuk menjalankan script Python).
  * Manajer Paket **Pip** (untuk pembaruan).
  * Untuk fitur web server, diperlukan paket Apache/MariaDB yang akan diinstal melalui *Full Setup*.

#### Langkah-Langkah Instalasi (Umum)

1.  **Setup Hackforge (Full Setup)**: Pilih opsi ini dari **MAIN MENU** (Gambar 4) untuk memastikan semua komponen server (Apache, MariaDB) dan direktori yang diperlukan terinstal.

    > **Catatan:** LIONCIX HACKFORGE beroperasi di direktori *Web Root* dan *Hackforge Dir* seperti yang ditunjukkan: `C:\Users\User\htdocs` dan `C:\Users\User\hackforge`.

### 🚀 Cara Penggunaan

1.  Jalankan program utama.
2.  Dari **MENU UTAMA – TERMUX & WINDOWS TOOL** (Gambar 3), pilih salah satu opsi:

      * **[1] Jalankan Script Python:** Untuk menjalankan script Python.
      * **[2] Jalankan Server Web:** Untuk mengaktifkan server lokal.
      * **[3] Install Packages / [4] Update Pip:** Untuk pengelolaan *package*.
      * **[5] Informasi Sistem:** Untuk melihat detail sistem.
3.  Untuk mengoperasikan Server Web, *Database*, dan *Web Interface*, kembali ke **MAIN MENU** (Gambar 4) dan gunakan opsi **[2] START Services** atau **[3] STOP Services**.
4.  Untuk melakukan pemindaian keamanan, pilih menu yang relevan (misalnya, **Website Security Scanning**).

### 🛡️ Website Security Scanning Tools (Contoh)

| No. | Tools | Deskripsi |
| :-- | :--- | :--- |
| 1. | Scan Keamanan Website Lengkap | Pemindaian keamanan menyeluruh. |
| 2. | Cek Kerentanan SQL Injection (Advanced) | Deteksi kerentanan *SQL Injection* tingkat lanjut. |
| 3. | Cek Kerentanan XSS (Advanced) | Deteksi kerentanan *Cross-Site Scripting* (XSS). |
| 4. | Port Scanner (Comprehensive) | Pemindaian *port* secara komprehensif. |
| 7. | Directory & File Bruteforce | Mencari direktori dan file tersembunyi. |
| 11. | Vulnerability Report | Laporan kerentanan yang ditemukan. |

### 🗺️ Flowchart Struktur Menu Utama

Struktur menu utama LIONCIX HACKFORGE divisualisasikan sebagai berikut:

```mermaid
graph TD
    A[START] --> B(MENU UTAMA);
    B --> B1[1. Jalankan Script Python];
    B --> B2[2. Jalankan Server Web];
    B --> B3[3. Install Packages];
    B --> B4[4. Update Pip];
    B --> B5[5. Informasi Sistem];
    B --> B0[0. Keluar]:::exit;
    B --> B6[Pilih Opsi 6: MAIN MENU - HACKFORGE STATUS];

    B6 --> C[MAIN MENU - HACKFORGE STATUS];
    C --> C1[1. Install Hackforge (Full Setup)];
    C --> C2[2. START Services];
    C --> C3[3. STOP Services];
    C --> C4[4. RESTART Services];
    C --> C5[5. Open Web Interface];
    C --> C6[6. Open PhpMyAdmin];
    C --> C7[7. System Info];
    C --> B[0. Exit/Kembali];

    C --> D[Pilih Opsi Lain dari MAIN MENU];
    D --> E(Website Security Scanning);
    D --> F(Tool Management);
    D --> G(Development);
    D --> H(OSINT & Social Tools);
    D --> I(Download & Resources);
    D --> J(Advanced Tools);
    D --> K(Token Generator Menu);
    D --> L(System - Settings);

    E --> E1[List 12 Scanning Tools...];
    E --> C[0. Kembali ke Menu Utama];

    F --> F1[1. Install Hacking Tools];
    F --> F2[2. Run Installed Tools];
    F --> C[0. Kembali ke Menu Utama];

    G --> G1[1. PHP Project Manager];
    G --> C[0. Kembali ke Menu Utama];

    H --> H1[1. Social Media Tools];
    H --> H2[2. OSINT Phone Number Lookup];
    H --> C[0. Kembali ke Menu Utama];

    I --> I1[1. Download Virus Collection];
    I --> C[0. Kembali ke Menu Utama];

    J --> J1[1. Backend & PHP Analysis];
    J --> J2[2. cPanel Project Dumper];
    J --> J3[3. DDoS Attack Tools];
    J --> C[0. Kembali ke Menu Utama];

    K --> K1[List 7 Token Generator Options...];
    K --> K0[0. Exit/Kembali];
    
    L --> L1[1. Settings & Configuration];
    L --> L2[2. About & Help];
    L --> C[0. Kembali ke Menu Utama];

    classDef exit fill:#f9f,stroke:#333,stroke-width:2px;
```
### 📝 Deskripsi Proyek

**LIONCIX HACKFORGE** adalah alat siber multifungsi yang menyediakan *suite* lengkap untuk keamanan web, pengujian penetrasi, pengembangan, dan intelijen sumber terbuka (OSINT). Alat ini dirancang dengan antarmuka terminal yang *stylish* dan mudah dinavigasi, berjalan di lingkungan **Windows** dan **Termux**.

### 🛠️ Alur Instalasi dan Setup Awal

Program ini dijalankan menggunakan **Python** dan memiliki langkah-langkah *setup* otomatis dan manual.

#### 1\. Memulai Program

  * Navigasi ke direktori utama *LIONCIX HACKFORGE* di Terminal/Command Prompt.
  * Jalankan program utama dengan perintah: `python gui.py`

#### 2\. Sound & Audio Dependencies (Termux)

Saat pertama kali dijalankan, sistem akan memeriksa fitur suara:

| Status | Pesan (ID) | Tindakan Pengguna |
| :--- | :--- | :--- |
| **Peringatan** | **[SOUND] Memeriksa fitur sound... Fitur sound tidak tersedia.** (Gambar 14 & 13) | Pengguna akan ditanya apakah ingin menginstal *audio dependencies*. |
| **Instalasi** | **Untuk mengaktifkan sound, install sox dan termux-api: `pkg install sox termux-api`** | Jika pengguna memilih **Y**, instalasi akan dilanjutkan (di Termux). |
| **Fallback** | **Menggunakan fallback sound (Python beep)** | Jika pengguna memilih **N**, program akan tetap berjalan menggunakan *Python beep* sebagai pengganti suara. |

#### 3\. Menu Pilihan Instalasi Hackforge (PILIHAN INSTALASI HACKFORGE)

Setelah pengecekan awal, pengguna diarahkan ke menu instalasi untuk menentukan bagaimana komponen akan disiapkan (Gambar 13):

| Opsi | Deskripsi | Status Sound |
| :--- | :--- | :--- |
| **1** | Install dependencies manual (package Termux) | `FALLBACK ONLY` |
| **2** | Install py requirements.txt | |
| **3** | Running Now HackForge (skip instalasi) | Langsung menjalankan program. |
| **4** | Run Web Script (Php Admin) | Menjalankan script admin PHP. |
| **5** | Run Exploitation Hacking (Games) | Menjalankan alat eksploitasi dan *hacking* (*Games*). |
| **6** | Run Token Generator (JWT) | Menjalankan fitur *Token Generator* khusus (JWT). |
| **7** | Keluar | Keluar dari program. |

### 🧭 Struktur Menu Kategori Utama

Setelah *setup* selesai, pengguna akan masuk ke **Menu Utama: PILIH KATEGORI** (Gambar 11). Ini adalah menu navigasi utama untuk mengakses seluruh fitur Hackforge:

| No. | Kategori | Ringkasan Fitur | Lihat Menu Detail di... |
| :--- | :--- | :--- | :--- |
| **1.** | **Website Security Scanning** 🔒 | Pemindaian keamanan web, SQLi, XSS, Port Scan, DNS/WHOIS, SSL/TLS, *Vulnerability Report*. | *(Gambar 12)* |
| **2.** | **Advanced Tools** 🔧 | Backend & PHP Analysis, cPanel Project Dumper, DDoS Attack Tools. | *(Gambar 10)* |
| **3.** | **Tool Management** 🚀 | Instalasi Koleksi *Hacking Tools* lengkap dan menjalankan *tools* yang sudah terinstal. | *(Gambar 8)* |
| **4.** | **Download & Resources** 💾 | Akses ke sumber daya eksternal seperti *Download Virus Collection* (GitHub). | *(Gambar 9)* |
| **5.** | **Social Media & OSINT** 🔎 | Alat *Phone Number Lookup* dan *Social Media Tools* (*Followers/Views*). | *(Gambar 7)* |
| **6.** | **Development** ⚙️ | PHP Project Manager (*Create/Run/Delete*). | *(Gambar 6)* |
| **7.** | **System** 💻 | Settings & Configuration, About & Help. | *(Gambar 5)* |
| **0.** | **Keluar** 🚪 | Keluar dari program. | |

-----

### 🗺️ Flowchart Lengkap (Termasuk Setup Awal)

Berikut adalah *flowchart* yang diperbarui untuk mencakup proses *startup* dan navigasi menu:

```mermaid
graph TD
    A[START: python gui.py] --> B{Memeriksa Fitur Sound};
    B -- Fitur Sound Tidak Tersedia --> C{Install Audio Dependencies? (y/n)};
    C -- Y --> D[Install sox & termux-api];
    C -- N --> E[Menggunakan Fallback Sound (Python beep)];
    D --> F[PILIHAN INSTALASI HACKFORGE];
    E --> F;

    subgraph Setup Options
        F --> F1[1. Install dependencies manual (package Termux)];
        F --> F2[2. Install py requirements.txt];
        F --> F3[3. Running Now HackForge (skip instalasi)];
        F --> F4[4. Run Web Script (Php Admin)];
        F --> F5[5. Run Exploitation Hacking (Games)];
        F --> F6[6. Run Token Generator (JWT)];
        F --> F7[7. Keluar]:::exit;
    end

    F3 --> G(Menu Utama: PILIH KATEGORI);

    subgraph Main Categories
        G --> G1[1. Website Security Scanning 🔒];
        G --> G2[2. Advanced Tools 🔧];
        G --> G3[3. Tool Management 🚀];
        G --> G4[4. Download & Resources 💾];
        G --> G5[5. Social Media & OSINT 🔎];
        G --> G6[6. Development ⚙️];
        G --> G7[7. System 💻];
        G --> G0[0. Keluar]:::exit;
    end

    G1 --> I1[Scanning Tools Menu (12 Opsi)] & J[Jalankan Script Python/Server/Update Pip (Menu Awal)];
    G2 --> I2[Advanced Tools Menu];
    G3 --> I3[Tool Management Menu];
    G4 --> I4[Download Center Menu];
    G5 --> I5[OSINT & Social Tools Menu];
    G6 --> I6[Development Menu];
    G7 --> I7[System Settings Menu];
    I1 --> G; I2 --> G; I3 --> G; I4 --> G; I5 --> G; I6 --> G; I7 --> G;
    J --> J1(MAIN MENU - HACKFORGE STATUS);
    J1 --> G;

    classDef exit fill:#f9f,stroke:#333,stroke-width:2px;
```